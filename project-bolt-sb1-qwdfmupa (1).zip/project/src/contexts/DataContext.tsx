import React, { createContext, useContext, useState, useEffect } from 'react';
import { Validator, Reward, NetworkStats } from '../types';
import axios from 'axios';

interface DataContextProps {
  validators: Validator[];
  rewards: Reward[];
  networkStats: NetworkStats;
  isLoading: boolean;
  refetchData: () => void;
  getValidatorById: (id: string) => Validator | undefined;
  getValidatorRewards: (id: string) => Reward[];
}

const DataContext = createContext<DataContextProps | undefined>(undefined);

const API_URL = '/api';
const RPC_URL = 'https://aeneid.storyrpc.io';

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [validators, setValidators] = useState<Validator[]>([]);
  const [rewards, setRewards] = useState<Reward[]>([]);
  const [networkStats, setNetworkStats] = useState<NetworkStats>({
    totalValidators: 0,
    activeValidators: 0,
    currentEpoch: 0,
    totalRewards: 0,
    averageUptime: 0,
    networkHealth: 0,
    epochStartTime: new Date().toISOString(),
    epochEndTime: new Date().toISOString(),
  });
  const [isLoading, setIsLoading] = useState(true);

  const fetchValidatorStats = async () => {
    try {
      const response = await axios.get(`${API_URL}/validators/statistics`, {
        headers: {
          'accept': 'application/json'
        }
      });

      const stats = response.data || {};
      
      // Transform API data to match our interface
      // Add defensive programming to handle undefined validators array
      const validatorsArray = stats.validators || [];
      const transformedValidators: Validator[] = validatorsArray.map((v: any) => ({
        id: v?.address || '',
        address: v?.address || '',
        name: v?.moniker || `Validator ${v?.address?.substring(0, 8) || 'Unknown'}`,
        stake: parseInt(v?.tokens || '0') / 1e6, // Convert to TALE
        uptime: (v?.uptime || 0) * 100,
        performanceScore: (v?.performance || 0) * 100,
        rewardsEarned: v?.rewards_earned || 0,
        lastActiveEpoch: v?.last_active_epoch || 0,
        isActive: v?.status === 'BOND_STATUS_BONDED',
        isSlashed: v?.jailed || false,
        region: v?.region || 'Unknown',
        type: v?.validator_type || 'solo',
        delegators: v?.delegator_count || 0,
        createdAt: v?.created_at || new Date().toISOString(),
      }));

      setValidators(transformedValidators);
      
      // Update network stats with defensive programming
      setNetworkStats({
        totalValidators: stats?.total_validators || 0,
        activeValidators: stats?.active_validators || 0,
        currentEpoch: stats?.current_epoch || 0,
        totalRewards: stats?.total_rewards || 0,
        averageUptime: (stats?.average_uptime || 0) * 100,
        networkHealth: (stats?.network_health || 0) * 100,
        epochStartTime: stats?.epoch_start_time || new Date().toISOString(),
        epochEndTime: stats?.epoch_end_time || new Date().toISOString(),
      });

    } catch (error) {
      console.error('Error fetching validator statistics:', error);
    }
  };

  const fetchData = async () => {
    setIsLoading(true);
    try {
      await fetchValidatorStats();
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // Initial data load
  useEffect(() => {
    fetchData();
  }, []);

  // Auto-refresh every 15 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      fetchValidatorStats();
    }, 15000);

    return () => clearInterval(interval);
  }, []);

  const getValidatorById = (id: string) => {
    return validators.find(validator => validator.id === id);
  };

  const getValidatorRewards = (id: string) => {
    return rewards.filter(reward => reward.validatorId === id);
  };

  return (
    <DataContext.Provider
      value={{
        validators,
        rewards,
        networkStats,
        isLoading,
        refetchData: fetchData,
        getValidatorById,
        getValidatorRewards,
      }}
    >
      {children}
    </DataContext.Provider>
  );
};

export const useData = (): DataContextProps => {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};