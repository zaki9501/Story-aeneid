import { Validator, Reward, NetworkStats } from '../types';
import { addDays, subDays, format } from 'date-fns';

// Helper to generate random data
const randomInt = (min: number, max: number) => Math.floor(Math.random() * (max - min + 1) + min);
const randomFloat = (min: number, max: number, decimals = 2) => parseFloat((Math.random() * (max - min) + min).toFixed(decimals));

// Generate mock validators
export const generateMockValidators = (count = 100): Validator[] => {
  const types: ('solo' | 'team' | 'org')[] = ['solo', 'team', 'org'];
  const regions = ['North America', 'Europe', 'Asia', 'South America', 'Africa', 'Oceania'];
  
  return Array.from({ length: count }).map((_, index) => {
    const isActive = Math.random() > 0.1;
    const isSlashed = Math.random() > 0.95;
    const uptime = isActive ? randomFloat(80, 100) : randomFloat(0, 80);
    
    return {
      id: `validator-${index + 1}`,
      address: `0x${Array.from({ length: 40 }).map(() => Math.floor(Math.random() * 16).toString(16)).join('')}`,
      name: `Validator ${index + 1}`,
      logo: index % 5 === 0 ? `https://picsum.photos/seed/${index}/200` : undefined,
      stake: randomInt(10000, 1000000),
      uptime,
      performanceScore: randomFloat(0, 100),
      rewardsEarned: randomInt(100, 10000),
      lastActiveEpoch: randomInt(1, 100),
      isActive,
      isSlashed,
      region: regions[randomInt(0, regions.length - 1)],
      type: types[randomInt(0, types.length - 1)],
      delegators: randomInt(0, 50),
      createdAt: format(subDays(new Date(), randomInt(1, 90)), 'yyyy-MM-dd'),
    };
  });
};

// Generate mock rewards
export const generateMockRewards = (validators: Validator[], epochs = 100): Reward[] => {
  let rewards: Reward[] = [];
  
  for (let epoch = 1; epoch <= epochs; epoch++) {
    const epochDate = subDays(new Date(), epochs - epoch);
    
    validators.forEach(validator => {
      if (validator.isActive && epoch > randomInt(1, 10)) {
        rewards.push({
          epoch,
          timestamp: format(epochDate, 'yyyy-MM-dd'),
          amount: randomInt(10, 100),
          validatorId: validator.id,
        });
      }
    });
  }
  
  return rewards;
};

// Generate mock network stats
export const generateNetworkStats = (): NetworkStats => {
  const totalValidators = randomInt(150, 200);
  const activeValidators = randomInt(100, totalValidators);
  const currentEpoch = randomInt(90, 110);
  
  const epochEndTime = new Date();
  const epochStartTime = subDays(epochEndTime, 1);
  
  return {
    totalValidators,
    activeValidators,
    currentEpoch,
    totalRewards: randomInt(100000, 1000000),
    averageUptime: randomFloat(95, 99.9),
    networkHealth: randomFloat(90, 99),
    epochStartTime: format(epochStartTime, 'yyyy-MM-dd\'T\'HH:mm:ss'),
    epochEndTime: format(epochEndTime, 'yyyy-MM-dd\'T\'HH:mm:ss'),
  };
};

// Pre-generate data for immediate use
export const mockValidators = generateMockValidators();
export const mockRewards = generateMockRewards(mockValidators);
export const mockNetworkStats = generateNetworkStats();

// Helper to get time series data for a specific validator
export const getValidatorTimeSeriesData = (validatorId: string, dataPoints = 30) => {
  const data = [];
  const now = new Date();
  
  for (let i = dataPoints; i >= 1; i--) {
    data.push({
      timestamp: format(subDays(now, i), 'yyyy-MM-dd'),
      stake: randomInt(10000, 1000000),
      uptime: randomFloat(80, 100),
      rewards: randomInt(10, 100),
    });
  }
  
  return data;
};