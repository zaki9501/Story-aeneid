import React from 'react';
import PageHeader from '../components/layout/PageHeader';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import { 
  BookOpen, 
  FileText, 
  Film, 
  HelpCircle,
  ArrowRight, 
  Award,
  ExternalLink,
} from 'lucide-react';
import { motion } from 'framer-motion';

interface ResourceCard {
  title: string;
  description: string;
  icon: React.ReactNode;
  type: string;
  link: string;
}

const resources: ResourceCard[] = [
  {
    title: "Validator Onboarding Guide",
    description: "A comprehensive guide on how to set up and run a validator node on the Story Protocol network.",
    icon: <FileText size={24} className="text-primary-600 dark:text-primary-400" />,
    type: "Documentation",
    link: "#"
  },
  {
    title: "Validator Economics",
    description: "Learn about the economic model, rewards, and incentives for validators in the Story Protocol ecosystem.",
    icon: <Award size={24} className="text-secondary-600 dark:text-secondary-400" />,
    type: "Article",
    link: "#"
  },
  {
    title: "Validator Node Setup Tutorial",
    description: "Step-by-step video tutorial showing how to set up a validator node from scratch.",
    icon: <Film size={24} className="text-accent-600 dark:text-accent-400" />,
    type: "Video",
    link: "#"
  },
  {
    title: "Validator Best Practices",
    description: "Essential tips and practices for running a high-performing validator node.",
    icon: <FileText size={24} className="text-primary-600 dark:text-primary-400" />,
    type: "Documentation",
    link: "#"
  },
  {
    title: "Understanding Slashing",
    description: "A detailed explanation of slashing conditions, penalties, and how to avoid them.",
    icon: <HelpCircle size={24} className="text-warning-500" />,
    type: "Article",
    link: "#"
  },
  {
    title: "Validator Security Checklist",
    description: "Essential security practices to protect your validator node and funds.",
    icon: <FileText size={24} className="text-primary-600 dark:text-primary-400" />,
    type: "Documentation",
    link: "#"
  },
];

const faqs = [
  {
    question: "What are the hardware requirements for running a validator?",
    answer: "Validators should have at least 8 CPU cores, 16GB RAM, 1TB SSD storage, and 100Mbps internet connection with low latency. It's recommended to use a dedicated server rather than a cloud instance for better performance."
  },
  {
    question: "What is the minimum stake required to become a validator?",
    answer: "For the Aeneid Testnet, validators need a minimum of 10,000 TALE tokens to participate. This requirement may change for the mainnet launch."
  },
  {
    question: "How are rewards calculated and distributed?",
    answer: "Rewards are calculated based on validator performance, uptime, and total stake. They are distributed at the end of each epoch. Higher uptime and performance scores result in higher rewards."
  },
  {
    question: "What causes a validator to get slashed?",
    answer: "Validators can be slashed for malicious behavior such as double signing (signing two different blocks at the same height) or extended downtime (being offline for more than 24 hours)."
  },
  {
    question: "Can I run multiple validator nodes?",
    answer: "Yes, you can run multiple validator nodes, but each must have its own identity and stake. Running multiple validators increases your potential rewards but also your operational complexity."
  },
];

const Learn: React.FC = () => {
  return (
    <div className="space-y-8">
      <PageHeader
        title="Learn About Validation"
        description="Educational resources and guides for Story Protocol validators"
      />
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <Card>
              <div className="p-6">
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
                  Resources & Guides
                </h2>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {resources.map((resource, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.5, delay: index * 0.1 }}
                    >
                      <Card 
                        hoverable
                        className="h-full border border-gray-100 dark:border-gray-700 hover:border-primary-200 dark:hover:border-primary-700"
                      >
                        <div className="p-5 flex flex-col h-full">
                          <div className="flex items-start mb-3">
                            <div className="flex-shrink-0">
                              {resource.icon}
                            </div>
                            <div className="ml-3">
                              <h3 className="text-lg font-medium text-gray-900 dark:text-white">
                                {resource.title}
                              </h3>
                              <span className="inline-block px-2 py-1 mt-1 text-xs font-medium bg-gray-100 dark:bg-gray-800 rounded-full text-gray-600 dark:text-gray-400">
                                {resource.type}
                              </span>
                            </div>
                          </div>
                          
                          <p className="text-sm text-gray-600 dark:text-gray-400 flex-grow">
                            {resource.description}
                          </p>
                          
                          <div className="mt-4 pt-2 border-t border-gray-100 dark:border-gray-800">
                            <a 
                              href={resource.link}
                              className="flex items-center text-primary-600 dark:text-primary-400 text-sm font-medium hover:text-primary-700 dark:hover:text-primary-300"
                            >
                              View Resource
                              <ExternalLink size={14} className="ml-1" />
                            </a>
                          </div>
                        </div>
                      </Card>
                    </motion.div>
                  ))}
                </div>
              </div>
            </Card>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
          >
            <Card title="Frequently Asked Questions">
              <div className="p-6">
                <div className="space-y-6">
                  {faqs.map((faq, index) => (
                    <div key={index} className="border-b border-gray-100 dark:border-gray-800 pb-6 last:border-0 last:pb-0">
                      <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2 flex items-start">
                        <HelpCircle size={20} className="text-primary-600 dark:text-primary-400 mr-2 flex-shrink-0 mt-1" />
                        <span>{faq.question}</span>
                      </h3>
                      <p className="text-gray-600 dark:text-gray-400 ml-7">{faq.answer}</p>
                    </div>
                  ))}
                </div>
                
                <div className="mt-6 text-center">
                  <p className="text-sm text-gray-500 dark:text-gray-400 mb-3">
                    Don't see your question here?
                  </p>
                  <Button 
                    variant="outline"
                  >
                    Contact Support
                  </Button>
                </div>
              </div>
            </Card>
          </motion.div>
        </div>
        
        <div className="lg:col-span-1 space-y-6">
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <Card>
              <div className="p-6">
                <div className="flex items-center mb-4">
                  <BookOpen size={24} className="text-primary-600 dark:text-primary-400 mr-2" />
                  <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                    Become a Validator
                  </h2>
                </div>
                
                <p className="text-gray-600 dark:text-gray-400 mb-6">
                  Interested in becoming a validator for Story Protocol? Follow our comprehensive
                  guide to set up your node and start earning rewards.
                </p>
                
                <div className="bg-primary-50 dark:bg-primary-900/20 rounded-lg p-4 mb-6 border border-primary-100 dark:border-primary-800">
                  <h3 className="text-lg font-medium text-primary-900 dark:text-primary-200 mb-2">
                    Requirements
                  </h3>
                  
                  <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-400">
                    <li className="flex items-start">
                      <span className="inline-flex items-center justify-center w-5 h-5 rounded-full bg-primary-200 dark:bg-primary-800 text-primary-700 dark:text-primary-300 mr-2 flex-shrink-0 text-xs">
                        ✓
                      </span>
                      Minimum 10,000 TALE tokens for staking
                    </li>
                    <li className="flex items-start">
                      <span className="inline-flex items-center justify-center w-5 h-5 rounded-full bg-primary-200 dark:bg-primary-800 text-primary-700 dark:text-primary-300 mr-2 flex-shrink-0 text-xs">
                        ✓
                      </span>
                      Server with 8+ CPU cores, 16GB+ RAM
                    </li>
                    <li className="flex items-start">
                      <span className="inline-flex items-center justify-center w-5 h-5 rounded-full bg-primary-200 dark:bg-primary-800 text-primary-700 dark:text-primary-300 mr-2 flex-shrink-0 text-xs">
                        ✓
                      </span>
                      1TB+ SSD storage
                    </li>
                    <li className="flex items-start">
                      <span className="inline-flex items-center justify-center w-5 h-5 rounded-full bg-primary-200 dark:bg-primary-800 text-primary-700 dark:text-primary-300 mr-2 flex-shrink-0 text-xs">
                        ✓
                      </span>
                      100Mbps+ internet connection
                    </li>
                    <li className="flex items-start">
                      <span className="inline-flex items-center justify-center w-5 h-5 rounded-full bg-primary-200 dark:bg-primary-800 text-primary-700 dark:text-primary-300 mr-2 flex-shrink-0 text-xs">
                        ✓
                      </span>
                      Technical knowledge of blockchain systems
                    </li>
                  </ul>
                </div>
                
                <Button
                  className="w-full"
                  rightIcon={<ArrowRight size={16} />}
                >
                  Start Validation Guide
                </Button>
                
                <div className="mt-6 pt-4 border-t border-gray-100 dark:border-gray-700">
                  <h3 className="font-medium text-gray-900 dark:text-white mb-2">
                    Already a validator?
                  </h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                    Check our troubleshooting guide or join our Discord community for technical support.
                  </p>
                  <Button variant="outline" className="w-full">
                    Get Technical Support
                  </Button>
                </div>
              </div>
            </Card>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            <Card title="Latest Updates">
              <div className="p-6">
                <div className="space-y-4">
                  <div className="border-l-2 border-primary-500 pl-4 py-1">
                    <div className="text-xs text-gray-500 dark:text-gray-400">June 15, 2025</div>
                    <h4 className="font-medium text-gray-900 dark:text-white mt-1">
                      Aeneid Testnet Phase 2 Launched
                    </h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                      New features for validators including improved rewards structure and performance tracking.
                    </p>
                  </div>
                  
                  <div className="border-l-2 border-gray-200 dark:border-gray-700 pl-4 py-1">
                    <div className="text-xs text-gray-500 dark:text-gray-400">May 28, 2025</div>
                    <h4 className="font-medium text-gray-900 dark:text-white mt-1">
                      Validator Node Software Update v0.3.0
                    </h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                      Critical security patches and performance improvements. All validators required to update.
                    </p>
                  </div>
                  
                  <div className="border-l-2 border-gray-200 dark:border-gray-700 pl-4 py-1">
                    <div className="text-xs text-gray-500 dark:text-gray-400">May 10, 2025</div>
                    <h4 className="font-medium text-gray-900 dark:text-white mt-1">
                      Validator Rewards Program Announced
                    </h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                      Top performing validators will receive additional incentives in the form of NFT badges and bonus rewards.
                    </p>
                  </div>
                </div>
                
                <div className="mt-4 text-sm text-right">
                  <a href="#" className="text-primary-600 dark:text-primary-400 font-medium hover:underline">
                    View all updates →
                  </a>
                </div>
              </div>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default Learn;