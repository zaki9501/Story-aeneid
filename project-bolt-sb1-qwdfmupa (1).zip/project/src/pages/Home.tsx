import React from 'react';
import PageHeader from '../components/layout/PageHeader';
import NetworkStatsSection from '../components/home/NetworkStatsSection';
import TopValidatorsSection from '../components/home/TopValidatorsSection';
import LiveDataWidget from '../components/home/LiveDataWidget';
import { RefreshCw } from 'lucide-react';
import Button from '../components/ui/Button';
import { useData } from '../contexts/DataContext';

const Home: React.FC = () => {
  const { refetchData, isLoading } = useData();

  return (
    <div className="space-y-8">
      <PageHeader
        title="Story Protocol Validator Dashboard"
        description="Real-time analytics for Aeneid Testnet validators"
        actions={
          <Button
            variant="outline"
            leftIcon={<RefreshCw size={16} />}
            onClick={refetchData}
            isLoading={isLoading}
          >
            Refresh Data
          </Button>
        }
      />
      
      <LiveDataWidget />
      
      <NetworkStatsSection />
      
      <TopValidatorsSection />
    </div>
  );
};

export default Home;