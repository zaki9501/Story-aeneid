import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import PageHeader from '../components/layout/PageHeader';
import Card from '../components/ui/Card';
import DataTable from '../components/ui/DataTable';
import Button from '../components/ui/Button';
import { useData } from '../contexts/DataContext';
import { Validator } from '../types';
import { 
  RefreshCw, 
  Filter, 
  CheckCircle, 
  XCircle, 
  Award, 
  AlertTriangle,
  Download
} from 'lucide-react';

const ValidatorExplorer: React.FC = () => {
  const { validators, isLoading, refetchData } = useData();
  const navigate = useNavigate();
  
  // Filter state
  const [filters, setFilters] = useState({
    status: 'all', // 'all', 'active', 'inactive'
    performance: 'all', // 'all', 'top10', 'slashed'
  });
  
  // Apply filters
  const filteredValidators = validators.filter(validator => {
    // Status filter
    if (filters.status === 'active' && !validator.isActive) return false;
    if (filters.status === 'inactive' && validator.isActive) return false;
    
    // Performance filter
    if (filters.performance === 'top10') {
      const top10Threshold = [...validators]
        .sort((a, b) => b.performanceScore - a.performanceScore)
        .slice(0, Math.ceil(validators.length * 0.1))
        .slice(-1)[0]?.performanceScore || 0;
        
      if (validator.performanceScore < top10Threshold) return false;
    }
    if (filters.performance === 'slashed' && !validator.isSlashed) return false;
    
    return true;
  });

  // Table columns
  const columns = [
    {
      header: 'Validator',
      accessor: (validator: Validator) => (
        <div className="flex items-center">
          {validator.logo ? (
            <img
              src={validator.logo}
              alt={validator.name}
              className="w-8 h-8 rounded-full mr-3 bg-gray-100"
            />
          ) : (
            <div className="w-8 h-8 rounded-full mr-3 bg-primary-100 dark:bg-primary-900/30 flex items-center justify-center">
              <span className="text-primary-700 dark:text-primary-300 text-sm font-bold">
                {validator.name.charAt(0)}
              </span>
            </div>
          )}
          <div>
            <div className="font-medium text-gray-900 dark:text-white">{validator.name}</div>
            <div className="text-xs text-gray-500 dark:text-gray-400">
              {validator.address.substring(0, 6)}...{validator.address.substring(validator.address.length - 4)}
            </div>
          </div>
          {validator.performanceScore > 95 && (
            <Award size={16} className="ml-2 text-warning-500" title="Top Performer" />
          )}
          {validator.isSlashed && (
            <AlertTriangle size={16} className="ml-2 text-error-500" title="Slashed" />
          )}
        </div>
      ),
    },
    {
      header: 'Status',
      accessor: (validator: Validator) => (
        <div className="flex items-center">
          {validator.isActive ? (
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-success-50 text-success-700 dark:bg-success-900/20 dark:text-success-300">
              <CheckCircle size={12} className="mr-1" /> Active
            </span>
          ) : (
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-300">
              <XCircle size={12} className="mr-1" /> Inactive
            </span>
          )}
        </div>
      ),
      sortable: true,
    },
    {
      header: 'Stake',
      accessor: (validator: Validator) => (
        <div className="font-medium">{validator.stake.toLocaleString()} TALE</div>
      ),
      sortable: true,
    },
    {
      header: 'Uptime',
      accessor: (validator: Validator) => (
        <div className="flex items-center">
          <div className="w-16 bg-gray-200 dark:bg-gray-700 rounded-full h-2 mr-2">
            <div 
              className={`h-2 rounded-full ${
                validator.uptime > 95 
                  ? 'bg-success-500' 
                  : validator.uptime > 80 
                    ? 'bg-warning-500' 
                    : 'bg-error-500'
              }`} 
              style={{ width: `${validator.uptime}%` }}
            ></div>
          </div>
          <span>{validator.uptime.toFixed(2)}%</span>
        </div>
      ),
      sortable: true,
    },
    {
      header: 'Performance',
      accessor: (validator: Validator) => (
        <div className="flex items-center">
          <div className="w-16 bg-gray-200 dark:bg-gray-700 rounded-full h-2 mr-2">
            <div 
              className="bg-primary-600 h-2 rounded-full" 
              style={{ width: `${validator.performanceScore}%` }}
            ></div>
          </div>
          <span>{validator.performanceScore.toFixed(1)}%</span>
        </div>
      ),
      sortable: true,
    },
    {
      header: 'Rewards',
      accessor: (validator: Validator) => (
        <div className="font-medium">{validator.rewardsEarned.toLocaleString()} TALE</div>
      ),
      sortable: true,
    },
    {
      header: 'Last Active',
      accessor: (validator: Validator) => (
        <div>Epoch #{validator.lastActiveEpoch}</div>
      ),
      sortable: true,
    },
  ];

  const handleRowClick = (validator: Validator) => {
    navigate(`/validators/${validator.id}`);
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Validators Explorer"
        description="Browse and analyze all validators on the Story Protocol Aeneid Testnet"
        actions={
          <div className="flex space-x-3">
            <Button
              variant="outline"
              leftIcon={<Download size={16} />}
            >
              Export CSV
            </Button>
            <Button
              variant="outline"
              leftIcon={<RefreshCw size={16} />}
              onClick={refetchData}
              isLoading={isLoading}
            >
              Refresh
            </Button>
          </div>
        }
      />

      <Card>
        <div className="p-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6 space-y-4 md:space-y-0">
            <div className="flex items-center space-x-2">
              <Filter size={18} className="text-gray-500 dark:text-gray-400" />
              <span className="font-medium text-gray-700 dark:text-gray-300">Filters:</span>
            </div>
            
            <div className="flex flex-wrap gap-2">
              <select
                value={filters.status}
                onChange={(e) => setFilters({ ...filters, status: e.target.value })}
                className="input py-1 px-3"
              >
                <option value="all">All Status</option>
                <option value="active">Active Only</option>
                <option value="inactive">Inactive Only</option>
              </select>
              
              <select
                value={filters.performance}
                onChange={(e) => setFilters({ ...filters, performance: e.target.value })}
                className="input py-1 px-3"
              >
                <option value="all">All Performance</option>
                <option value="top10">Top 10%</option>
                <option value="slashed">Slashed</option>
              </select>
            </div>
          </div>
          
          <DataTable
            data={filteredValidators}
            columns={columns}
            keyField="id"
            onRowClick={handleRowClick}
            searchable
            searchFields={['name', 'address']}
            pagination
            itemsPerPage={10}
          />
          
          <div className="mt-4 text-sm text-gray-500 dark:text-gray-400">
            Showing {filteredValidators.length} out of {validators.length} validators
          </div>
        </div>
      </Card>
    </div>
  );
};

export default ValidatorExplorer;