import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import PageHeader from '../components/layout/PageHeader';
import Card from '../components/ui/Card';
import DataTable from '../components/ui/DataTable';
import Button from '../components/ui/Button';
import { useData } from '../contexts/DataContext';
import { Validator } from '../types';
import { 
  Trophy, 
  Medal, 
  Award, 
  Filter,
  Download
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

type RankingCriteria = 'performance' | 'uptime' | 'rewards' | 'stake';
type TimeFrame = 'weekly' | 'monthly' | 'all';

const Leaderboard: React.FC = () => {
  const { validators } = useData();
  const navigate = useNavigate();
  
  const [rankBy, setRankBy] = useState<RankingCriteria>('performance');
  const [timeFrame, setTimeFrame] = useState<TimeFrame>('weekly');
  const [filters, setFilters] = useState({
    region: 'all',
    type: 'all',
  });
  
  // Apply filters
  const filteredValidators = validators
    .filter(validator => {
      if (filters.region !== 'all' && validator.region !== filters.region) return false;
      if (filters.type !== 'all' && validator.type !== filters.type) return false;
      return true;
    })
    .filter(validator => validator.isActive) // Only show active validators on leaderboard
    .sort((a, b) => {
      // Sort based on ranking criteria
      switch (rankBy) {
        case 'performance':
          return b.performanceScore - a.performanceScore;
        case 'uptime':
          return b.uptime - a.uptime;
        case 'rewards':
          return b.rewardsEarned - a.rewardsEarned;
        case 'stake':
          return b.stake - a.stake;
        default:
          return 0;
      }
    })
    .slice(0, 100); // Top 100 validators
  
  // Get all unique regions
  const regions = ['all', ...new Set(validators.map(v => v.region))];
  
  // Medal colors based on rank
  const getMedalColor = (index: number) => {
    if (index === 0) return 'text-yellow-400'; // Gold
    if (index === 1) return 'text-gray-400'; // Silver
    if (index === 2) return 'text-amber-600'; // Bronze
    return 'text-gray-300 dark:text-gray-600'; // Others
  };
  
  // Generate table columns
  const columns = [
    {
      header: 'Rank',
      accessor: (_: any, index: number) => (
        <div className="flex items-center justify-center">
          {index < 3 ? (
            <Medal className={`w-6 h-6 ${getMedalColor(index)}`} />
          ) : (
            <span className="font-medium">{index + 1}</span>
          )}
        </div>
      ),
      className: 'text-center',
    },
    {
      header: 'Validator',
      accessor: (validator: Validator) => (
        <div className="flex items-center">
          {validator.logo ? (
            <img
              src={validator.logo}
              alt={validator.name}
              className="w-8 h-8 rounded-full mr-3 bg-gray-100"
            />
          ) : (
            <div className="w-8 h-8 rounded-full mr-3 bg-primary-100 dark:bg-primary-900/30 flex items-center justify-center">
              <span className="text-primary-700 dark:text-primary-300 text-sm font-bold">
                {validator.name.charAt(0)}
              </span>
            </div>
          )}
          <div>
            <div className="font-medium text-gray-900 dark:text-white">{validator.name}</div>
            <div className="text-xs text-gray-500 dark:text-gray-400">
              {validator.address.substring(0, 6)}...{validator.address.substring(validator.address.length - 4)}
            </div>
          </div>
        </div>
      ),
    },
    {
      header: 'Region',
      accessor: 'region',
      sortable: true,
    },
    {
      header: 'Type',
      accessor: (validator: Validator) => (
        <span className="capitalize">{validator.type}</span>
      ),
      sortable: true,
    },
    {
      header: rankBy === 'performance' ? 'Performance Score' :
             rankBy === 'uptime' ? 'Uptime %' :
             rankBy === 'rewards' ? 'Rewards Earned' : 'Stake',
      accessor: (validator: Validator) => {
        switch (rankBy) {
          case 'performance':
            return `${validator.performanceScore.toFixed(2)}%`;
          case 'uptime':
            return `${validator.uptime.toFixed(2)}%`;
          case 'rewards':
            return `${validator.rewardsEarned.toLocaleString()} TALE`;
          case 'stake':
            return `${validator.stake.toLocaleString()} TALE`;
          default:
            return '';
        }
      },
      sortable: true,
      className: 'font-medium',
    },
  ];

  const handleRowClick = (validator: Validator) => {
    navigate(`/validators/${validator.id}`);
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Validator Leaderboard"
        description={`Top validators ranked by ${rankBy} metrics`}
        actions={
          <Button
            variant="outline"
            leftIcon={<Download size={16} />}
          >
            Export Rankings
          </Button>
        }
      />

      <Card>
        <div className="p-6">
          <div className="flex flex-col space-y-4 md:flex-row md:items-center md:justify-between md:space-y-0 mb-6">
            <div className="flex items-center space-x-2">
              <Trophy size={20} className="text-warning-500" />
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                Top Performers
              </h2>
            </div>
            
            <div className="flex flex-wrap gap-2 items-center">
              <div className="text-sm text-gray-500 dark:text-gray-400 mr-2">Rank by:</div>
              
              <div className="flex p-0.5 bg-gray-100 dark:bg-gray-800 rounded-md">
                <button
                  className={`px-3 py-1 text-sm rounded-md transition-colors ${
                    rankBy === 'performance' 
                      ? 'bg-white dark:bg-gray-700 shadow-sm' 
                      : 'text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white'
                  }`}
                  onClick={() => setRankBy('performance')}
                >
                  Performance
                </button>
                <button
                  className={`px-3 py-1 text-sm rounded-md transition-colors ${
                    rankBy === 'uptime' 
                      ? 'bg-white dark:bg-gray-700 shadow-sm' 
                      : 'text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white'
                  }`}
                  onClick={() => setRankBy('uptime')}
                >
                  Uptime
                </button>
                <button
                  className={`px-3 py-1 text-sm rounded-md transition-colors ${
                    rankBy === 'rewards' 
                      ? 'bg-white dark:bg-gray-700 shadow-sm' 
                      : 'text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white'
                  }`}
                  onClick={() => setRankBy('rewards')}
                >
                  Rewards
                </button>
                <button
                  className={`px-3 py-1 text-sm rounded-md transition-colors ${
                    rankBy === 'stake' 
                      ? 'bg-white dark:bg-gray-700 shadow-sm' 
                      : 'text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white'
                  }`}
                  onClick={() => setRankBy('stake')}
                >
                  Stake
                </button>
              </div>
            </div>
          </div>
          
          <div className="flex flex-col md:flex-row md:items-center justify-between mb-6 space-y-4 md:space-y-0">
            <div className="flex items-center space-x-4">
              <div className="flex p-0.5 bg-gray-100 dark:bg-gray-800 rounded-md">
                <button
                  className={`px-3 py-1 text-sm rounded-md transition-colors ${
                    timeFrame === 'weekly' 
                      ? 'bg-white dark:bg-gray-700 shadow-sm' 
                      : 'text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white'
                  }`}
                  onClick={() => setTimeFrame('weekly')}
                >
                  Weekly
                </button>
                <button
                  className={`px-3 py-1 text-sm rounded-md transition-colors ${
                    timeFrame === 'monthly' 
                      ? 'bg-white dark:bg-gray-700 shadow-sm' 
                      : 'text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white'
                  }`}
                  onClick={() => setTimeFrame('monthly')}
                >
                  Monthly
                </button>
                <button
                  className={`px-3 py-1 text-sm rounded-md transition-colors ${
                    timeFrame === 'all' 
                      ? 'bg-white dark:bg-gray-700 shadow-sm' 
                      : 'text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white'
                  }`}
                  onClick={() => setTimeFrame('all')}
                >
                  All Time
                </button>
              </div>
            </div>
            
            <div className="flex items-center space-x-3">
              <Filter size={16} className="text-gray-500 dark:text-gray-400" />
              
              <select
                value={filters.region}
                onChange={(e) => setFilters({ ...filters, region: e.target.value })}
                className="input py-1 px-2 text-sm"
              >
                {regions.map(region => (
                  <option key={region} value={region}>
                    {region === 'all' ? 'All Regions' : region}
                  </option>
                ))}
              </select>
              
              <select
                value={filters.type}
                onChange={(e) => setFilters({ ...filters, type: e.target.value })}
                className="input py-1 px-2 text-sm"
              >
                <option value="all">All Types</option>
                <option value="solo">Solo</option>
                <option value="team">Team</option>
                <option value="org">Organization</option>
              </select>
            </div>
          </div>
          
          <AnimatePresence mode="wait">
            <motion.div
              key={`${rankBy}-${timeFrame}-${filters.region}-${filters.type}`}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
            >
              <DataTable
                data={filteredValidators}
                columns={columns}
                keyField="id"
                onRowClick={handleRowClick}
                pagination
                itemsPerPage={20}
              />
            </motion.div>
          </AnimatePresence>
          
          <div className="mt-4 text-sm text-center text-gray-500 dark:text-gray-400 flex items-center justify-center">
            <Award className="w-4 h-4 mr-1.5 text-warning-500" />
            Top 3 validators earn additional rewards and special recognition
          </div>
        </div>
      </Card>
    </div>
  );
};

export default Leaderboard;