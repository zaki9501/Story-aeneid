import React, { useState, useMemo } from 'react';
import PageHeader from '../components/layout/PageHeader';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import LineChart from '../components/charts/LineChart';
import BarChart from '../components/charts/BarChart';
import { useData } from '../contexts/DataContext';
import { 
  DollarSign, 
  TrendingUp, 
  Calendar, 
  BarChartHorizontal, 
  Download,
  HelpCircle
} from 'lucide-react';
import { motion } from 'framer-motion';

type TimeFrame = 'weekly' | 'monthly' | 'all';

const RewardsAnalytics: React.FC = () => {
  const { rewards, validators, networkStats } = useData();
  const [timeFrame, setTimeFrame] = useState<TimeFrame>('weekly');
  
  // Process rewards data
  const rewardData = useMemo(() => {
    // Group rewards by epoch
    const rewardsByEpoch = rewards.reduce((acc, reward) => {
      if (!acc[reward.epoch]) {
        acc[reward.epoch] = {
          epoch: reward.epoch,
          timestamp: reward.timestamp,
          totalRewards: 0,
          validatorCount: new Set(),
        };
      }
      
      acc[reward.epoch].totalRewards += reward.amount;
      acc[reward.epoch].validatorCount.add(reward.validatorId);
      
      return acc;
    }, {} as Record<number, { epoch: number, timestamp: string, totalRewards: number, validatorCount: Set<string> }>);
    
    // Convert to array and add validator count
    return Object.values(rewardsByEpoch)
      .map(data => ({
        epoch: data.epoch,
        timestamp: data.timestamp,
        totalRewards: data.totalRewards,
        validatorCount: data.validatorCount.size,
        averageReward: data.totalRewards / data.validatorCount.size,
      }))
      .sort((a, b) => a.epoch - b.epoch);
  }, [rewards]);
  
  // Apply time frame filter
  const filteredRewardData = useMemo(() => {
    if (timeFrame === 'weekly') {
      return rewardData.slice(-7);
    } else if (timeFrame === 'monthly') {
      return rewardData.slice(-30);
    }
    return rewardData;
  }, [rewardData, timeFrame]);
  
  // Calculate top 5 validators by rewards
  const topRewardValidators = useMemo(() => {
    const validatorRewards = validators.map(validator => {
      return {
        id: validator.id,
        name: validator.name,
        rewards: validator.rewardsEarned,
      };
    }).sort((a, b) => b.rewards - a.rewards).slice(0, 5);
    
    return validatorRewards;
  }, [validators]);
  
  // Reward distribution by validator type
  const rewardsByType = useMemo(() => {
    const typeRewards = validators.reduce((acc, validator) => {
      if (!acc[validator.type]) {
        acc[validator.type] = 0;
      }
      acc[validator.type] += validator.rewardsEarned;
      return acc;
    }, {} as Record<string, number>);
    
    return Object.entries(typeRewards).map(([type, amount]) => ({
      name: type.charAt(0).toUpperCase() + type.slice(1),
      amount,
    }));
  }, [validators]);
  
  return (
    <div className="space-y-6">
      <PageHeader
        title="Rewards Analytics"
        description="Track and analyze rewards distribution across the network"
        actions={
          <Button
            variant="outline"
            leftIcon={<Download size={16} />}
          >
            Export Data
          </Button>
        }
      />
      
      <motion.div 
        className="grid grid-cols-1 md:grid-cols-3 gap-6"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Card className="col-span-1">
          <div className="p-6">
            <div className="flex items-center mb-4">
              <DollarSign className="w-5 h-5 text-primary-600 dark:text-primary-400 mr-2" />
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Total Rewards</h2>
            </div>
            
            <div className="text-3xl font-bold text-gray-900 dark:text-white">
              {networkStats.totalRewards.toLocaleString()} <span className="text-lg">TALE</span>
            </div>
            
            <div className="mt-2 text-sm text-gray-500 dark:text-gray-400">
              Distributed over {networkStats.currentEpoch} epochs
            </div>
            
            <div className="mt-6 pt-4 border-t border-gray-100 dark:border-gray-700">
              <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">Rewards by Validator Type</h3>
              
              {rewardsByType.map((item, index) => (
                <div key={index} className="mb-2">
                  <div className="flex justify-between mb-1">
                    <span className="text-sm text-gray-600 dark:text-gray-400">{item.name}</span>
                    <span className="text-sm font-medium text-gray-800 dark:text-gray-200">
                      {item.amount.toLocaleString()} TALE
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                    <div 
                      className="bg-primary-600 h-2 rounded-full" 
                      style={{ width: `${(item.amount / networkStats.totalRewards) * 100}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </Card>
        
        <Card className="col-span-1 md:col-span-2">
          <div className="p-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-4">
              <div className="flex items-center mb-3 sm:mb-0">
                <BarChartHorizontal className="w-5 h-5 text-primary-600 dark:text-primary-400 mr-2" />
                <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Rewards Distribution</h2>
              </div>
              
              <div className="flex p-0.5 bg-gray-100 dark:bg-gray-800 rounded-md self-start sm:self-auto">
                <button
                  className={`px-3 py-1 text-sm rounded-md transition-colors ${
                    timeFrame === 'weekly' 
                      ? 'bg-white dark:bg-gray-700 shadow-sm' 
                      : 'text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white'
                  }`}
                  onClick={() => setTimeFrame('weekly')}
                >
                  Weekly
                </button>
                <button
                  className={`px-3 py-1 text-sm rounded-md transition-colors ${
                    timeFrame === 'monthly' 
                      ? 'bg-white dark:bg-gray-700 shadow-sm' 
                      : 'text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white'
                  }`}
                  onClick={() => setTimeFrame('monthly')}
                >
                  Monthly
                </button>
                <button
                  className={`px-3 py-1 text-sm rounded-md transition-colors ${
                    timeFrame === 'all' 
                      ? 'bg-white dark:bg-gray-700 shadow-sm' 
                      : 'text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white'
                  }`}
                  onClick={() => setTimeFrame('all')}
                >
                  All Time
                </button>
              </div>
            </div>
            
            <BarChart
              data={filteredRewardData}
              xDataKey="epoch"
              bars={[
                { dataKey: 'totalRewards', name: 'Total Rewards', color: '#7c3aed' },
                { dataKey: 'averageReward', name: 'Avg Reward per Validator', color: '#0d9488' },
              ]}
              xAxisLabel="Epoch"
              yAxisLabel="Rewards (TALE)"
            />
            
            <div className="mt-6 pt-4 border-t border-gray-100 dark:border-gray-700">
              <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-4">Reward Projection</h3>
              
              <div className="bg-accent-50 dark:bg-accent-900/20 p-4 rounded-lg border border-accent-100 dark:border-accent-800">
                <div className="flex items-center mb-2">
                  <Calendar className="w-5 h-5 text-accent-600 dark:text-accent-400 mr-2" />
                  <h4 className="font-medium text-gray-900 dark:text-white">Projected Next Epoch Rewards</h4>
                </div>
                
                <div className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                  Based on current network performance and stake distribution
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-xl font-semibold text-gray-900 dark:text-white">
                      ~{Math.floor(networkStats.totalRewards * 0.01).toLocaleString()} TALE
                    </div>
                    <div className="text-sm text-gray-500 dark:text-gray-400">
                      Total network rewards
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <div className="text-lg font-semibold text-gray-900 dark:text-white">
                      ~{Math.floor((networkStats.totalRewards * 0.01) / networkStats.activeValidators).toLocaleString()} TALE
                    </div>
                    <div className="text-sm text-gray-500 dark:text-gray-400">
                      Average per validator
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </Card>
      </motion.div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card title="Top Reward Earners" className="col-span-1">
          <div className="p-6">
            <div className="space-y-5">
              {topRewardValidators.map((validator, index) => (
                <div key={validator.id} className="flex items-center">
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center mr-3 ${
                    index === 0 ? 'bg-yellow-100 text-yellow-600' :
                    index === 1 ? 'bg-gray-100 text-gray-600' :
                    index === 2 ? 'bg-amber-100 text-amber-600' :
                    'bg-gray-50 text-gray-500'
                  }`}>
                    {index + 1}
                  </div>
                  
                  <div className="flex-1">
                    <div className="text-sm font-medium text-gray-900 dark:text-white">{validator.name}</div>
                  </div>
                  
                  <div className="font-semibold text-right">
                    {validator.rewards.toLocaleString()} <span className="text-xs text-gray-500">TALE</span>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="mt-6 pt-4 border-t border-gray-100 dark:border-gray-700 text-sm text-center text-gray-500 dark:text-gray-400">
              Showing top {topRewardValidators.length} of {validators.length} validators
            </div>
          </div>
        </Card>
        
        <Card title="Reward Calculation" className="col-span-1">
          <div className="p-6">
            <div className="flex items-center mb-4">
              <HelpCircle size={18} className="text-primary-600 dark:text-primary-400 mr-2" />
              <h3 className="font-medium text-gray-900 dark:text-white">How Rewards Work</h3>
            </div>
            
            <div className="space-y-4 text-gray-600 dark:text-gray-400 text-sm">
              <p>
                Story Protocol distributes rewards to validators based on several factors:
              </p>
              
              <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
                <ul className="list-disc list-inside space-y-2">
                  <li><span className="font-medium">Performance Score</span> - How well the validator performs consensus duties</li>
                  <li><span className="font-medium">Uptime</span> - Percentage of time the validator is online and available</li>
                  <li><span className="font-medium">Stake Amount</span> - Total amount of TALE staked with the validator</li>
                  <li><span className="font-medium">Network Activity</span> - Overall network usage and transaction volume</li>
                </ul>
              </div>
              
              <p>
                The basic formula for calculating rewards is:
              </p>
              
              <div className="bg-gray-50 dark:bg-gray-800 p-3 rounded-lg font-mono text-gray-700 dark:text-gray-300 text-center">
                Base Reward × Performance Multiplier × Stake Weight
              </div>
              
              <p>
                Where Performance Multiplier is derived from uptime and consensus participation, 
                and Stake Weight is proportional to the validator's stake compared to the total network stake.
              </p>
              
              <div className="text-xs text-gray-500 dark:text-gray-400 mt-2">
                Note: Reward mechanics may be adjusted during the testnet phase as the protocol evolves.
              </div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default RewardsAnalytics;