import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import PageHeader from '../components/layout/PageHeader';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import LineChart from '../components/charts/LineChart';
import { useData } from '../contexts/DataContext';
import { 
  ArrowLeft, 
  Download, 
  ExternalLink, 
  Clock, 
  TrendingUp,
  AlertTriangle,
  Users,
  DollarSign,
  CheckCircle,
  XCircle
} from 'lucide-react';
import { getValidatorTimeSeriesData } from '../utils/mockData';
import { motion } from 'framer-motion';

const ValidatorDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { getValidatorById, validators, networkStats } = useData();
  const [timeseriesData, setTimeseriesData] = useState<any[]>([]);
  
  const validator = getValidatorById(id || '');
  
  useEffect(() => {
    if (id) {
      // Fetch time series data for this validator
      const data = getValidatorTimeSeriesData(id, 30);
      setTimeseriesData(data);
    }
  }, [id]);
  
  if (!validator) {
    return (
      <div className="flex flex-col items-center justify-center h-64">
        <h2 className="text-xl font-medium text-gray-700 dark:text-gray-300">Validator not found</h2>
        <Button
          variant="outline"
          leftIcon={<ArrowLeft size={16} />}
          onClick={() => navigate('/validators')}
          className="mt-4"
        >
          Back to Validators
        </Button>
      </div>
    );
  }
  
  // Calculate validator rank
  const sortedValidators = [...validators]
    .sort((a, b) => b.performanceScore - a.performanceScore);
  const validatorRank = sortedValidators.findIndex(v => v.id === validator.id) + 1;
  
  return (
    <div className="space-y-6">
      <PageHeader
        title="Validator Details"
        description="Detailed performance metrics and analytics"
        actions={
          <div className="flex space-x-3">
            <Button
              variant="outline"
              leftIcon={<ArrowLeft size={16} />}
              onClick={() => navigate('/validators')}
            >
              Back
            </Button>
            <Button
              variant="outline"
              leftIcon={<Download size={16} />}
            >
              Export Report
            </Button>
          </div>
        }
      />
      
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="grid grid-cols-1 lg:grid-cols-3 gap-6"
      >
        {/* Validator Info Card */}
        <Card className="col-span-1">
          <div className="p-6">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center">
                {validator.logo ? (
                  <img
                    src={validator.logo}
                    alt={validator.name}
                    className="w-16 h-16 rounded-full mr-4 bg-gray-100"
                  />
                ) : (
                  <div className="w-16 h-16 rounded-full mr-4 bg-primary-100 dark:bg-primary-900/30 flex items-center justify-center">
                    <span className="text-primary-700 dark:text-primary-300 text-2xl font-bold">
                      {validator.name.charAt(0)}
                    </span>
                  </div>
                )}
                <div>
                  <h1 className="text-xl font-bold text-gray-900 dark:text-white">{validator.name}</h1>
                  <div className="flex items-center mt-1">
                    <span className="text-sm text-gray-500 dark:text-gray-400 font-mono">
                      {validator.address.substring(0, 8)}...{validator.address.substring(validator.address.length - 8)}
                    </span>
                    <button className="ml-2 text-gray-400 hover:text-gray-500 dark:text-gray-500 dark:hover:text-gray-400">
                      <ExternalLink size={14} />
                    </button>
                  </div>
                </div>
              </div>
              <div>
                {validator.isActive ? (
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-success-50 text-success-700 dark:bg-success-900/20 dark:text-success-300">
                    <CheckCircle size={12} className="mr-1" /> Active
                  </span>
                ) : (
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-300">
                    <XCircle size={12} className="mr-1" /> Inactive
                  </span>
                )}
                {validator.isSlashed && (
                  <div className="mt-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-error-50 text-error-700 dark:bg-error-900/20 dark:text-error-300">
                    <AlertTriangle size={12} className="mr-1" /> Slashed
                  </div>
                )}
              </div>
            </div>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between py-2 border-b border-gray-100 dark:border-gray-700">
                <span className="text-sm text-gray-500 dark:text-gray-400">Type</span>
                <span className="font-medium text-gray-900 dark:text-white capitalize">{validator.type}</span>
              </div>
              
              <div className="flex items-center justify-between py-2 border-b border-gray-100 dark:border-gray-700">
                <span className="text-sm text-gray-500 dark:text-gray-400">Region</span>
                <span className="font-medium text-gray-900 dark:text-white">{validator.region}</span>
              </div>
              
              <div className="flex items-center justify-between py-2 border-b border-gray-100 dark:border-gray-700">
                <span className="text-sm text-gray-500 dark:text-gray-400">Joined</span>
                <span className="font-medium text-gray-900 dark:text-white">{validator.createdAt}</span>
              </div>
              
              <div className="flex items-center justify-between py-2 border-b border-gray-100 dark:border-gray-700">
                <span className="text-sm text-gray-500 dark:text-gray-400">Last Active Epoch</span>
                <span className="font-medium text-gray-900 dark:text-white">#{validator.lastActiveEpoch}</span>
              </div>
              
              <div className="flex items-center justify-between py-2 border-b border-gray-100 dark:border-gray-700">
                <span className="text-sm text-gray-500 dark:text-gray-400">Leaderboard Rank</span>
                <div className="flex items-center">
                  <span className="font-medium text-gray-900 dark:text-white">#{validatorRank}</span>
                  <span className="ml-1 text-xs text-gray-500 dark:text-gray-400">of {validators.length}</span>
                </div>
              </div>
              
              <div className="flex items-center justify-between py-2">
                <span className="text-sm text-gray-500 dark:text-gray-400">Delegators</span>
                <div className="flex items-center">
                  <Users size={16} className="text-primary-600 dark:text-primary-400 mr-1.5" />
                  <span className="font-medium text-gray-900 dark:text-white">{validator.delegators}</span>
                </div>
              </div>
            </div>
          </div>
        </Card>
        
        {/* Performance Metrics */}
        <Card className="col-span-1 lg:col-span-2">
          <div className="p-6">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-6">Performance Metrics</h2>
            
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-8">
              <div className="bg-white dark:bg-gray-800/50 p-4 rounded-lg border border-gray-100 dark:border-gray-700">
                <div className="flex justify-between items-start mb-2">
                  <span className="text-sm text-gray-500 dark:text-gray-400">Performance Score</span>
                  <span className={`text-sm font-medium ${
                    validator.performanceScore > 90 ? 'text-success-600 dark:text-success-400' :
                    validator.performanceScore > 70 ? 'text-warning-600 dark:text-warning-400' :
                    'text-error-600 dark:text-error-400'
                  }`}>
                    {validator.performanceScore > 90 ? 'Excellent' :
                     validator.performanceScore > 70 ? 'Good' : 'Poor'}
                  </span>
                </div>
                <div className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
                  {validator.performanceScore.toFixed(1)}%
                </div>
                <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                  <div 
                    className={`h-2 rounded-full ${
                      validator.performanceScore > 90 ? 'bg-success-500' :
                      validator.performanceScore > 70 ? 'bg-warning-500' :
                      'bg-error-500'
                    }`} 
                    style={{ width: `${validator.performanceScore}%` }}
                  ></div>
                </div>
              </div>
              
              <div className="bg-white dark:bg-gray-800/50 p-4 rounded-lg border border-gray-100 dark:border-gray-700">
                <div className="flex justify-between items-start mb-2">
                  <span className="text-sm text-gray-500 dark:text-gray-400">Uptime</span>
                  <TrendingUp size={16} className="text-success-500" />
                </div>
                <div className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
                  {validator.uptime.toFixed(2)}%
                </div>
                <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                  <div 
                    className={`h-2 rounded-full ${
                      validator.uptime > 95 ? 'bg-success-500' :
                      validator.uptime > 80 ? 'bg-warning-500' :
                      'bg-error-500'
                    }`} 
                    style={{ width: `${validator.uptime}%` }}
                  ></div>
                </div>
              </div>
              
              <div className="bg-white dark:bg-gray-800/50 p-4 rounded-lg border border-gray-100 dark:border-gray-700">
                <div className="flex justify-between items-start mb-2">
                  <span className="text-sm text-gray-500 dark:text-gray-400">Rewards Earned</span>
                  <DollarSign size={16} className="text-success-500" />
                </div>
                <div className="text-2xl font-bold text-gray-900 dark:text-white">
                  {validator.rewardsEarned.toLocaleString()} <span className="text-sm font-medium">TALE</span>
                </div>
                <div className="flex items-center mt-2">
                  <Clock size={14} className="text-gray-400 dark:text-gray-500 mr-1.5" />
                  <span className="text-xs text-gray-500 dark:text-gray-400">
                    Last reward: Epoch #{networkStats.currentEpoch - 1}
                  </span>
                </div>
              </div>
            </div>
            
            <div className="border-t border-gray-100 dark:border-gray-700 pt-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-medium text-gray-900 dark:text-white">Historical Performance</h3>
                
                <div className="flex space-x-2">
                  <button className="text-xs font-medium px-2 py-1 rounded-md bg-primary-50 dark:bg-primary-900/20 text-primary-700 dark:text-primary-300">
                    30 Days
                  </button>
                  <button className="text-xs font-medium px-2 py-1 rounded-md text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700">
                    90 Days
                  </button>
                  <button className="text-xs font-medium px-2 py-1 rounded-md text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700">
                    All Time
                  </button>
                </div>
              </div>
              
              <LineChart
                data={timeseriesData}
                xDataKey="timestamp"
                lines={[
                  { dataKey: 'stake', name: 'Stake', color: '#7c3aed' },
                  { dataKey: 'uptime', name: 'Uptime %', color: '#0d9488' },
                  { dataKey: 'rewards', name: 'Rewards', color: '#3b82f6' }
                ]}
                className="mt-2"
              />
            </div>
          </div>
        </Card>
      </motion.div>
      
      {/* Additional Info Sections */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card title="Delegators">
          <div className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <span className="text-3xl font-bold text-gray-900 dark:text-white">{validator.delegators}</span>
                <span className="ml-2 text-gray-500 dark:text-gray-400">total delegators</span>
              </div>
              <Button variant="outline" size="sm">
                View All
              </Button>
            </div>
            
            <p className="text-gray-500 dark:text-gray-400 text-sm">
              Delegator information is currently simulated for the testnet phase. In the production version, 
              this section will show detailed information about each delegator, including their stake amount 
              and delegation history.
            </p>
          </div>
        </Card>
        
        <Card title="Slashing Events">
          <div className="p-6">
            {validator.isSlashed ? (
              <div className="space-y-4">
                <div className="bg-error-50 dark:bg-error-900/20 p-4 rounded-lg border border-error-200 dark:border-error-800">
                  <div className="flex items-center">
                    <AlertTriangle size={20} className="text-error-600 dark:text-error-400 mr-2" />
                    <span className="font-medium text-error-700 dark:text-error-300">Slashing Event Detected</span>
                  </div>
                  <p className="mt-2 text-sm text-gray-600 dark:text-gray-400">
                    This validator was slashed at Epoch #{networkStats.currentEpoch - 10} for double signing.
                    A penalty of 100 TALE was applied.
                  </p>
                </div>
                
                <div className="text-sm text-gray-500 dark:text-gray-400">
                  Slashing events are serious penalties applied for validator misbehavior, 
                  such as double signing or extended downtime.
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-8">
                <CheckCircle size={48} className="text-success-500 mb-4" />
                <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">No Slashing Events</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400 text-center">
                  This validator has maintained good behavior and has not been slashed.
                </p>
              </div>
            )}
          </div>
        </Card>
      </div>
    </div>
  );
};

export default ValidatorDetails;