import React, { useEffect, useState } from 'react';
import PageHeader from '../components/layout/PageHeader';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import { useData } from '../contexts/DataContext';
import { Layers, Maximize, Minimize, MapPin, Network as NetworkIcon } from 'lucide-react';
import NetworkGraph from '../components/charts/NetworkGraph';
import { motion } from 'framer-motion';

const NetworkVisualization: React.FC = () => {
  const { validators } = useData();
  const [visualizationType, setVisualizationType] = useState<'network' | 'geo'>('network');
  const [zoom, setZoom] = useState(100);
  
  // Generate network nodes and links from validators
  const [networkData, setNetworkData] = useState<{ nodes: any[], links: any[] }>({
    nodes: [],
    links: [],
  });
  
  useEffect(() => {
    // Generate nodes from validators
    const nodes = validators.map(validator => ({
      id: validator.id,
      name: validator.name,
      group: validator.type === 'solo' ? 1 : validator.type === 'team' ? 2 : 3,
      size: Math.max(5, Math.min(15, validator.stake / 100000)),
    }));
    
    // Generate random links between nodes (in a real app, these would represent actual relationships)
    const links: { source: string; target: string; value: number }[] = [];
    
    // Create connections between validators of the same type
    nodes.forEach(node => {
      // Find other nodes of the same group
      const sameGroupNodes = nodes.filter(n => n.group === node.group && n.id !== node.id);
      
      // Create links to some random nodes in the same group
      const numLinks = Math.floor(Math.random() * 3) + 1; // 1-3 links
      
      for (let i = 0; i < Math.min(numLinks, sameGroupNodes.length); i++) {
        const randomIndex = Math.floor(Math.random() * sameGroupNodes.length);
        const targetNode = sameGroupNodes[randomIndex];
        
        // Check if this link already exists
        const linkExists = links.some(
          link => 
            (link.source === node.id && link.target === targetNode.id) ||
            (link.source === targetNode.id && link.target === node.id)
        );
        
        if (!linkExists) {
          links.push({
            source: node.id,
            target: targetNode.id,
            value: Math.floor(Math.random() * 5) + 1, // 1-5 connection strength
          });
        }
        
        // Remove the node to avoid duplicate links
        sameGroupNodes.splice(randomIndex, 1);
      }
    });
    
    setNetworkData({ nodes, links });
  }, [validators]);
  
  const handleZoomIn = () => {
    setZoom(prev => Math.min(prev + 10, 150));
  };
  
  const handleZoomOut = () => {
    setZoom(prev => Math.max(prev - 10, 50));
  };
  
  return (
    <div className="space-y-6">
      <PageHeader
        title="Network Visualization"
        description="Interactive visualization of the validator network"
      />
      
      <Card>
        <div className="p-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-6 space-y-4 sm:space-y-0">
            <div className="flex items-center space-x-4">
              <div className="flex p-0.5 bg-gray-100 dark:bg-gray-800 rounded-md">
                <button
                  className={`px-4 py-2 text-sm rounded-md flex items-center transition-colors ${
                    visualizationType === 'network' 
                      ? 'bg-white dark:bg-gray-700 shadow-sm' 
                      : 'text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white'
                  }`}
                  onClick={() => setVisualizationType('network')}
                >
                  <NetworkIcon size={16} className="mr-2" /> Network View
                </button>
                <button
                  className={`px-4 py-2 text-sm rounded-md flex items-center transition-colors ${
                    visualizationType === 'geo' 
                      ? 'bg-white dark:bg-gray-700 shadow-sm' 
                      : 'text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white'
                  }`}
                  onClick={() => setVisualizationType('geo')}
                >
                  <MapPin size={16} className="mr-2" /> Geo View
                </button>
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={handleZoomOut}
                className="p-1.5"
              >
                <Minimize size={16} />
              </Button>
              
              <div className="w-24 bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                <div 
                  className="bg-primary-600 h-2 rounded-full" 
                  style={{ width: `${zoom}%` }}
                ></div>
              </div>
              
              <Button
                variant="outline"
                size="sm"
                onClick={handleZoomIn}
                className="p-1.5"
              >
                <Maximize size={16} />
              </Button>
              
              <span className="text-sm text-gray-500 dark:text-gray-400 ml-2">{zoom}%</span>
            </div>
          </div>
          
          <div className="border border-gray-200 dark:border-gray-700 rounded-lg overflow-hidden">
            <div style={{ height: '600px' }}>
              {visualizationType === 'network' ? (
                <motion.div
                  key="network-view"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.5 }}
                  style={{ height: '100%' }}
                >
                  <NetworkGraph 
                    nodes={networkData.nodes} 
                    links={networkData.links}
                    width={800 * (zoom / 100)}
                    height={600 * (zoom / 100)}
                    className="h-full"
                  />
                </motion.div>
              ) : (
                <motion.div
                  key="geo-view"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.5 }}
                  className="flex items-center justify-center h-full bg-gray-50 dark:bg-gray-800"
                >
                  <div className="text-center">
                    <Layers size={48} className="text-gray-400 dark:text-gray-600 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">Geographic View Coming Soon</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400 max-w-md mx-auto">
                      This feature will show validators on a world map with heatmap overlays for density and performance metrics.
                    </p>
                  </div>
                </motion.div>
              )}
            </div>
          </div>
          
          <div className="mt-4 bg-gray-50 dark:bg-gray-800 p-3 rounded-lg">
            <div className="text-sm flex items-start">
              <div className="flex-shrink-0 mt-0.5">
                <svg className="w-5 h-5 text-primary-600 dark:text-primary-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                  <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd"></path>
                </svg>
              </div>
              <p className="ml-2 text-gray-600 dark:text-gray-400">
                <span className="font-medium text-gray-900 dark:text-white">Network View Legend:</span> Node size represents stake amount, 
                and colors represent validator types (Purple: Solo, Teal: Team, Blue: Organization). 
                Connections between nodes represent communication and consensus relationships.
              </p>
            </div>
          </div>
        </div>
      </Card>
      
      <Card title="Network Statistics" className="col-span-1">
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
              <div className="text-sm text-gray-500 dark:text-gray-400 mb-1">Average Connections</div>
              <div className="text-xl font-bold text-gray-900 dark:text-white">
                {(networkData.links.length / networkData.nodes.length).toFixed(1)}
              </div>
              <div className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                Per validator
              </div>
            </div>
            
            <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
              <div className="text-sm text-gray-500 dark:text-gray-400 mb-1">Network Density</div>
              <div className="text-xl font-bold text-gray-900 dark:text-white">
                {(networkData.links.length / (networkData.nodes.length * (networkData.nodes.length - 1) / 2) * 100).toFixed(1)}%
              </div>
              <div className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                Percentage of potential connections
              </div>
            </div>
            
            <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
              <div className="text-sm text-gray-500 dark:text-gray-400 mb-1">Most Connected</div>
              <div className="text-xl font-bold text-gray-900 dark:text-white">
                Organization
              </div>
              <div className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                Validator type
              </div>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default NetworkVisualization;