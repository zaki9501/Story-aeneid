import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './components/layout/Layout';
import { ThemeProvider } from './contexts/ThemeContext';
import { DataProvider } from './contexts/DataContext';

// Page Components
import Home from './pages/Home';
import ValidatorExplorer from './pages/ValidatorExplorer';
import ValidatorDetails from './pages/ValidatorDetails';
import Leaderboard from './pages/Leaderboard';
import RewardsAnalytics from './pages/RewardsAnalytics';
import NetworkVisualization from './pages/NetworkVisualization';
import Learn from './pages/Learn';
import Settings from './pages/Settings';

function App() {
  return (
    <ThemeProvider>
      <DataProvider>
        <Router>
          <Layout>
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/validators" element={<ValidatorExplorer />} />
              <Route path="/validators/:id" element={<ValidatorDetails />} />
              <Route path="/leaderboard" element={<Leaderboard />} />
              <Route path="/rewards" element={<RewardsAnalytics />} />
              <Route path="/network" element={<NetworkVisualization />} />
              <Route path="/learn" element={<Learn />} />
              <Route path="/settings" element={<Settings />} />
            </Routes>
          </Layout>
        </Router>
      </DataProvider>
    </ThemeProvider>
  );
}

export default App;