// Validator Types
export interface Validator {
  id: string;
  address: string;
  name: string;
  logo?: string;
  stake: number;
  uptime: number;
  performanceScore: number;
  rewardsEarned: number;
  lastActiveEpoch: number;
  isActive: boolean;
  isSlashed: boolean;
  region: string;
  type: 'solo' | 'team' | 'org';
  delegators: number;
  createdAt: string;
}

// Reward Types
export interface Reward {
  epoch: number;
  timestamp: string;
  amount: number;
  validatorId: string;
}

// Network Statistics
export interface NetworkStats {
  totalValidators: number;
  activeValidators: number;
  currentEpoch: number;
  totalRewards: number;
  averageUptime: number;
  networkHealth: number;
  epochStartTime: string;
  epochEndTime: string;
}

// Chart Data Types
export interface TimeSeriesDataPoint {
  timestamp: string;
  value: number;
}

export interface ChartDataPoint {
  name: string;
  value: number;
}

// Theme type
export type Theme = 'light' | 'dark';