import React from 'react';
import { useNavigate } from 'react-router-dom';
import Card from '../ui/Card';
import { Award, Check, AlertTriangle, Clock } from 'lucide-react';
import { Validator } from '../../types';
import { motion } from 'framer-motion';

interface ValidatorCardProps {
  validator: Validator;
}

const ValidatorCard: React.FC<ValidatorCardProps> = ({ validator }) => {
  const navigate = useNavigate();
  
  const handleClick = () => {
    navigate(`/validators/${validator.id}`);
  };
  
  return (
    <Card 
      hoverable 
      onClick={handleClick}
      className="h-full"
    >
      <div className="p-4 flex flex-col h-full">
        <div className="flex items-start justify-between">
          <div className="flex items-center">
            {validator.logo ? (
              <img
                src={validator.logo}
                alt={validator.name}
                className="w-10 h-10 rounded-full mr-3 bg-gray-100"
              />
            ) : (
              <div className="w-10 h-10 rounded-full mr-3 bg-primary-100 dark:bg-primary-900/30 flex items-center justify-center">
                <span className="text-primary-700 dark:text-primary-300 text-lg font-bold">
                  {validator.name.charAt(0)}
                </span>
              </div>
            )}
            <div>
              <h3 className="text-lg font-medium text-gray-900 dark:text-white">{validator.name}</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400 truncate" style={{ maxWidth: '200px' }}>
                {validator.address.substring(0, 8)}...{validator.address.substring(validator.address.length - 6)}
              </p>
            </div>
          </div>
          
          <div>
            {validator.isActive ? (
              <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-success-50 text-success-700 dark:bg-success-900/20 dark:text-success-300">
                <Check size={12} className="mr-1" /> Active
              </span>
            ) : (
              <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-300">
                <Clock size={12} className="mr-1" /> Inactive
              </span>
            )}
            
            {validator.isSlashed && (
              <span className="ml-2 inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-error-50 text-error-700 dark:bg-error-900/20 dark:text-error-300">
                <AlertTriangle size={12} className="mr-1" /> Slashed
              </span>
            )}
          </div>
        </div>
        
        <div className="mt-4 space-y-3 flex-grow">
          <div>
            <div className="flex justify-between mb-1 text-sm">
              <span className="text-gray-600 dark:text-gray-400">Performance</span>
              <span className="font-medium text-gray-900 dark:text-white">{validator.performanceScore.toFixed(1)}%</span>
            </div>
            <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
              <motion.div 
                className="bg-primary-600 h-2 rounded-full"
                initial={{ width: 0 }}
                animate={{ width: `${validator.performanceScore}%` }}
                transition={{ duration: 1, type: 'spring' }}
              ></motion.div>
            </div>
          </div>
          
          <div>
            <div className="flex justify-between mb-1 text-sm">
              <span className="text-gray-600 dark:text-gray-400">Uptime</span>
              <span className="font-medium text-gray-900 dark:text-white">{validator.uptime.toFixed(2)}%</span>
            </div>
            <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
              <motion.div 
                className="bg-secondary-600 h-2 rounded-full"
                initial={{ width: 0 }}
                animate={{ width: `${validator.uptime}%` }}
                transition={{ duration: 1, type: 'spring', delay: 0.2 }}
              ></motion.div>
            </div>
          </div>
        </div>
        
        <div className="mt-4 pt-3 border-t border-gray-100 dark:border-gray-700 flex justify-between items-center">
          <div className="text-sm text-gray-500 dark:text-gray-400">
            <span className="mr-3">Stake: {validator.stake.toLocaleString()} TALE</span>
          </div>
          
          <div className="flex items-center">
            {validator.performanceScore > 95 && (
              <span className="mr-1">
                <Award size={16} className="text-warning-500" />
              </span>
            )}
            <span className="text-xs text-primary-600 dark:text-primary-400 font-medium">
              View details
            </span>
          </div>
        </div>
      </div>
    </Card>
  );
};

export default ValidatorCard;