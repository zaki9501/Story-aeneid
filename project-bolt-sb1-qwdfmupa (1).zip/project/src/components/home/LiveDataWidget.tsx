import React, { useEffect, useState } from 'react';
import { Clock, Zap } from 'lucide-react';
import Card from '../ui/Card';
import { motion } from 'framer-motion';
import { useData } from '../../contexts/DataContext';

const LiveDataWidget: React.FC = () => {
  const { networkStats } = useData();
  const [timeLeft, setTimeLeft] = useState<string>('');
  const [lastUpdated, setLastUpdated] = useState<string>(new Date().toISOString());
  
  // Calculate epoch end time
  useEffect(() => {
    const calculateTimeLeft = () => {
      const epochEnd = new Date(networkStats.epochEndTime);
      const now = new Date();
      const difference = epochEnd.getTime() - now.getTime();
      
      if (difference <= 0) {
        // Epoch already ended
        setTimeLeft('00:00:00');
        return;
      }
      
      // Calculate hours, minutes, seconds
      let hours: string | number = Math.floor((difference / (1000 * 60 * 60)));
      let minutes: string | number = Math.floor((difference / 1000 / 60) % 60);
      let seconds: string | number = Math.floor((difference / 1000) % 60);
      
      // Format numbers to have two digits
      hours = hours < 10 ? `0${hours}` : hours;
      minutes = minutes < 10 ? `0${minutes}` : minutes;
      seconds = seconds < 10 ? `0${seconds}` : seconds;
      
      setTimeLeft(`${hours}:${minutes}:${seconds}`);
    };
    
    // Initial calculation
    calculateTimeLeft();
    
    // Update time every second
    const timer = setInterval(() => {
      calculateTimeLeft();
    }, 1000);
    
    return () => clearInterval(timer);
  }, [networkStats.epochEndTime]);
  
  // Update last updated timestamp
  useEffect(() => {
    const interval = setInterval(() => {
      setLastUpdated(new Date().toISOString());
    }, 15000); // Every 15 seconds
    
    return () => clearInterval(interval);
  }, []);
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.3 }}
    >
      <Card className="bg-gray-50 dark:bg-gray-800/50">
        <div className="p-4">
          <div className="flex items-center mb-3">
            <div className="flex items-center">
              <Zap className="w-5 h-5 text-primary-600 dark:text-primary-400 mr-2" />
              <h3 className="text-lg font-medium text-gray-900 dark:text-white">Live Network Data</h3>
            </div>
            <div className="ml-auto flex items-center">
              <span className="relative flex h-3 w-3 mr-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-success-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-success-500"></span>
              </span>
              <span className="text-xs text-gray-500 dark:text-gray-400">
                Auto-refreshing every 15s
              </span>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-white dark:bg-gray-800 p-4 rounded-lg">
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium text-gray-500 dark:text-gray-400">Current Epoch</span>
                <span className="badge bg-primary-50 dark:bg-primary-900/30 text-primary-700 dark:text-primary-300">
                  #{networkStats.currentEpoch}
                </span>
              </div>
              
              <div className="flex items-center mb-2">
                <Clock className="w-4 h-4 text-gray-500 dark:text-gray-400 mr-2" />
                <span className="text-sm text-gray-500 dark:text-gray-400">Time Remaining</span>
              </div>
              
              <div className="text-2xl font-bold text-gray-900 dark:text-white">
                {timeLeft}
              </div>
            </div>
            
            <div className="bg-white dark:bg-gray-800 p-4 rounded-lg">
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium text-gray-500 dark:text-gray-400">Active Validators</span>
                <motion.div
                  key={`active-${networkStats.activeValidators}`}
                  initial={{ scale: 1.2, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ duration: 0.3 }}
                  className="badge bg-success-50 dark:bg-success-900/30 text-success-700 dark:text-success-300"
                >
                  {networkStats.activeValidators} / {networkStats.totalValidators}
                </motion.div>
              </div>
              
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium text-gray-500 dark:text-gray-400">Network Health</span>
                <span className="text-success-600 dark:text-success-400 text-sm font-medium">
                  {networkStats.networkHealth.toFixed(2)}%
                </span>
              </div>
              
              <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5 mb-4">
                <motion.div 
                  className="bg-success-500 h-2.5 rounded-full"
                  initial={{ width: 0 }}
                  animate={{ width: `${networkStats.networkHealth}%` }}
                  transition={{ duration: 1, type: 'spring' }}
                ></motion.div>
              </div>
              
              <div className="text-xs text-right text-gray-500 dark:text-gray-400">
                Last updated: {new Date(lastUpdated).toLocaleTimeString()}
              </div>
            </div>
          </div>
        </div>
      </Card>
    </motion.div>
  );
};

export default LiveDataWidget;