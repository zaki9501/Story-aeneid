import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useData } from '../../contexts/DataContext';
import Card from '../ui/Card';
import DataTable from '../ui/DataTable';
import { Award, Star, TrendingUp } from 'lucide-react';
import { Validator } from '../../types';
import { motion } from 'framer-motion';

const TopValidatorsSection: React.FC = () => {
  const { validators } = useData();
  const navigate = useNavigate();

  // Get top validators by performance score
  const topValidators = [...validators]
    .filter(validator => validator.isActive)
    .sort((a, b) => b.performanceScore - a.performanceScore)
    .slice(0, 5);

  const columns = [
    {
      header: 'Validator',
      accessor: (validator: Validator) => (
        <div className="flex items-center">
          {validator.performanceScore > 95 && (
            <Star className="w-4 h-4 text-warning-500 mr-2" />
          )}
          <span>{validator.name}</span>
        </div>
      ),
    },
    {
      header: 'Performance',
      accessor: (validator: Validator) => (
        <div className="flex items-center">
          <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5 mr-2">
            <div 
              className="bg-primary-600 h-2.5 rounded-full" 
              style={{ width: `${validator.performanceScore}%` }}
            ></div>
          </div>
          <span>{validator.performanceScore.toFixed(1)}%</span>
        </div>
      ),
      className: 'w-1/3',
    },
    {
      header: 'Uptime',
      accessor: (validator: Validator) => `${validator.uptime.toFixed(2)}%`,
    },
    {
      header: 'Rewards',
      accessor: (validator: Validator) => `${validator.rewardsEarned} TALE`,
    },
  ];

  const handleValidatorClick = (validator: Validator) => {
    navigate(`/validators/${validator.id}`);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
    >
      <Card 
        title="Top Performing Validators" 
        subtitle="Based on performance score over the last 30 days"
      >
        <div className="p-4">
          <div className="flex items-center mb-4">
            <Award className="w-5 h-5 text-primary-600 dark:text-primary-400 mr-2" />
            <h3 className="text-lg font-medium text-gray-900 dark:text-white">Performance Leaders</h3>
            <TrendingUp className="w-4 h-4 text-success-500 ml-2" />
          </div>
          
          <DataTable
            data={topValidators}
            columns={columns}
            keyField="id"
            onRowClick={handleValidatorClick}
          />
          
          <div className="mt-4 text-right">
            <button
              onClick={() => navigate('/validators')}
              className="text-sm text-primary-600 dark:text-primary-400 hover:text-primary-700 dark:hover:text-primary-300 font-medium"
            >
              View all validators →
            </button>
          </div>
        </div>
      </Card>
    </motion.div>
  );
};

export default TopValidatorsSection;