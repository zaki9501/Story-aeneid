import React from 'react';
import { motion } from 'framer-motion';
import { 
  Users, 
  Check, 
  Clock, 
  DollarSign, 
  Zap
} from 'lucide-react';
import StatsCard from '../ui/StatsCard';
import Card from '../ui/Card';
import DonutChart from '../charts/DonutChart';
import { useData } from '../../contexts/DataContext';
import { ChartDataPoint } from '../../types';

const NetworkStatsSection: React.FC = () => {
  const { networkStats, validators } = useData();
  
  // Calculate statistics for charts
  const validatorStatusData: ChartDataPoint[] = [
    { name: 'Active', value: validators.filter(v => v.isActive).length },
    { name: 'Inactive', value: validators.filter(v => !v.isActive).length },
  ];
  
  const validatorTypeData: ChartDataPoint[] = [
    { name: 'Solo', value: validators.filter(v => v.type === 'solo').length },
    { name: 'Team', value: validators.filter(v => v.type === 'team').length },
    { name: 'Organization', value: validators.filter(v => v.type === 'org').length },
  ];

  // Format numbers for display
  const formatNumber = (num: number) => {
    return new Intl.NumberFormat('en-US').format(num);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatsCard
          title="Total Validators"
          value={formatNumber(networkStats.totalValidators)}
          icon={<Users size={24} className="text-primary-600 dark:text-primary-400" />}
          change={{ value: 2.5, isPositive: true }}
        />
        
        <StatsCard
          title="Active Validators"
          value={formatNumber(networkStats.activeValidators)}
          icon={<Check size={24} className="text-secondary-600 dark:text-secondary-400" />}
          change={{ value: 1.8, isPositive: true }}
        />
        
        <StatsCard
          title="Current Epoch"
          value={formatNumber(networkStats.currentEpoch)}
          icon={<Clock size={24} className="text-accent-600 dark:text-accent-400" />}
        />
        
        <StatsCard
          title="Total Rewards"
          value={`${formatNumber(networkStats.totalRewards)} TALE`}
          icon={<DollarSign size={24} className="text-success-500" />}
          change={{ value: 5.2, isPositive: true }}
        />
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card title="Network Health" className="col-span-1">
          <div className="p-4">
            <div className="flex items-center justify-between mb-6">
              <div>
                <div className="flex items-center">
                  <Zap size={20} className="text-primary-600 dark:text-primary-400 mr-2" />
                  <h4 className="text-lg font-medium">Network Uptime</h4>
                </div>
                <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">
                  Last 30 days network performance
                </p>
              </div>
              <div className="bg-success-50 text-success-700 px-2 py-1 rounded-full text-xs font-medium">
                Healthy
              </div>
            </div>
            
            <div className="space-y-5">
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Average Uptime</span>
                  <span className="text-sm font-medium text-gray-700 dark:text-gray-300">{networkStats.averageUptime.toFixed(2)}%</span>
                </div>
                <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
                  <div 
                    className="bg-primary-600 h-2.5 rounded-full" 
                    style={{ width: `${networkStats.averageUptime}%` }}
                  ></div>
                </div>
              </div>
              
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Network Health</span>
                  <span className="text-sm font-medium text-gray-700 dark:text-gray-300">{networkStats.networkHealth.toFixed(2)}%</span>
                </div>
                <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
                  <div 
                    className="bg-secondary-600 h-2.5 rounded-full" 
                    style={{ width: `${networkStats.networkHealth}%` }}
                  ></div>
                </div>
              </div>
              
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Active Rate</span>
                  <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    {((networkStats.activeValidators / networkStats.totalValidators) * 100).toFixed(2)}%
                  </span>
                </div>
                <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
                  <div 
                    className="bg-accent-600 h-2.5 rounded-full" 
                    style={{ width: `${(networkStats.activeValidators / networkStats.totalValidators) * 100}%` }}
                  ></div>
                </div>
              </div>
            </div>
          </div>
        </Card>
        
        <div className="col-span-1 grid grid-cols-1 sm:grid-cols-2 gap-6">
          <Card title="Validator Status">
            <div className="p-4">
              <DonutChart data={validatorStatusData} colors={['#22c55e', '#ef4444']} />
            </div>
          </Card>
          
          <Card title="Validator Types">
            <div className="p-4">
              <DonutChart data={validatorTypeData} colors={['#7c3aed', '#0d9488', '#3b82f6']} />
            </div>
          </Card>
        </div>
      </div>
    </motion.div>
  );
};

export default NetworkStatsSection;