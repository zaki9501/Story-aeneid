import React from 'react';
import {
  BarChart as RechartsBarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from 'recharts';

interface BarChartProps {
  data: any[];
  xDataKey: string;
  bars: {
    dataKey: string;
    name: string;
    color: string;
    stackId?: string;
  }[];
  className?: string;
  yAxisLabel?: string;
  xAxisLabel?: string;
  yAxisWidth?: number;
  grid?: boolean;
}

const BarChart: React.FC<BarChartProps> = ({
  data,
  xDataKey,
  bars,
  className = '',
  yAxisLabel,
  xAxisLabel,
  yAxisWidth = 60,
  grid = true,
}) => {
  return (
    <div className={`w-full h-80 ${className}`}>
      <ResponsiveContainer width="100%" height="100%">
        <RechartsBarChart
          data={data}
          margin={{
            top: 20,
            right: 30,
            left: 20,
            bottom: 5,
          }}
        >
          {grid && <CartesianGrid strokeDasharray="3 3\" stroke="#e5e7eb" />}
          <XAxis 
            dataKey={xDataKey} 
            tick={{ fill: '#6b7280' }}
            axisLine={{ stroke: '#d1d5db' }}
            tickLine={{ stroke: '#d1d5db' }}
            label={xAxisLabel ? { value: xAxisLabel, position: 'insideBottomRight', offset: -10 } : undefined}
          />
          <YAxis 
            width={yAxisWidth}
            tick={{ fill: '#6b7280' }}
            axisLine={{ stroke: '#d1d5db' }}
            tickLine={{ stroke: '#d1d5db' }}
            label={yAxisLabel ? { value: yAxisLabel, angle: -90, position: 'insideLeft' } : undefined}
          />
          <Tooltip 
            contentStyle={{ 
              backgroundColor: 'rgba(255, 255, 255, 0.9)', 
              borderRadius: '8px',
              border: 'none',
              boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)'
            }}
          />
          <Legend />
          {bars.map((bar, index) => (
            <Bar
              key={index}
              dataKey={bar.dataKey}
              name={bar.name}
              fill={bar.color}
              stackId={bar.stackId}
              radius={[4, 4, 0, 0]}
            />
          ))}
        </RechartsBarChart>
      </ResponsiveContainer>
    </div>
  );
};

export default BarChart;