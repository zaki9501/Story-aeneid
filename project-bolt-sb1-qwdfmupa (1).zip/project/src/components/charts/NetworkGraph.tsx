import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';

interface Node {
  id: string;
  name: string;
  group: number;
  size: number;
}

interface Link {
  source: string;
  target: string;
  value: number;
}

interface NetworkGraphProps {
  nodes: Node[];
  links: Link[];
  width?: number;
  height?: number;
  className?: string;
}

const NetworkGraph: React.FC<NetworkGraphProps> = ({
  nodes,
  links,
  width = 800,
  height = 600,
  className = '',
}) => {
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    if (!svgRef.current || !nodes.length || !links.length) return;

    const svg = d3.select(svgRef.current);
    svg.selectAll("*").remove();

    // Define color scale
    const color = d3.scaleOrdinal(d3.schemeCategory10);

    // Create a force simulation
    const simulation = d3.forceSimulation<Node & d3.SimulationNodeDatum>(nodes)
      .force("link", d3.forceLink<Node, Link & d3.SimulationLinkDatum<Node>>(links).id(d => d.id))
      .force("charge", d3.forceManyBody().strength(-100))
      .force("center", d3.forceCenter(width / 2, height / 2))
      .force("collide", d3.forceCollide().radius(d => (d as Node).size * 2));

    // Create links
    const link = svg.append("g")
      .attr("stroke", "#999")
      .attr("stroke-opacity", 0.6)
      .selectAll("line")
      .data(links)
      .join("line")
      .attr("stroke-width", d => Math.sqrt(d.value));

    // Create nodes
    const node = svg.append("g")
      .selectAll("g")
      .data(nodes)
      .join("g")
      .call(drag(simulation));

    // Add circles to nodes
    node.append("circle")
      .attr("r", d => d.size)
      .attr("fill", d => color(d.group.toString()))
      .attr("stroke", "#fff")
      .attr("stroke-width", 1.5);

    // Add text labels
    node.append("text")
      .text(d => d.name)
      .attr("x", d => d.size + 5)
      .attr("y", 3)
      .attr("font-size", "10px")
      .attr("fill", "#666");

    // Add titles for tooltips
    node.append("title")
      .text(d => `${d.name} (${d.id})`);

    // Update positions on simulation tick
    simulation.on("tick", () => {
      link
        .attr("x1", d => (d.source as unknown as Node & d3.SimulationNodeDatum).x!)
        .attr("y1", d => (d.source as unknown as Node & d3.SimulationNodeDatum).y!)
        .attr("x2", d => (d.target as unknown as Node & d3.SimulationNodeDatum).x!)
        .attr("y2", d => (d.target as unknown as Node & d3.SimulationNodeDatum).y!);

      node.attr("transform", d => `translate(${d.x}, ${d.y})`);
    });

    // Drag functionality
    function drag(simulation: d3.Simulation<Node & d3.SimulationNodeDatum, undefined>) {
      function dragstarted(event: d3.D3DragEvent<SVGGElement, Node, Node & d3.SimulationNodeDatum>) {
        if (!event.active) simulation.alphaTarget(0.3).restart();
        event.subject.fx = event.subject.x;
        event.subject.fy = event.subject.y;
      }

      function dragged(event: d3.D3DragEvent<SVGGElement, Node, Node & d3.SimulationNodeDatum>) {
        event.subject.fx = event.x;
        event.subject.fy = event.y;
      }

      function dragended(event: d3.D3DragEvent<SVGGElement, Node, Node & d3.SimulationNodeDatum>) {
        if (!event.active) simulation.alphaTarget(0);
        event.subject.fx = null;
        event.subject.fy = null;
      }

      return d3.drag<SVGGElement, Node & d3.SimulationNodeDatum>()
        .on("start", dragstarted)
        .on("drag", dragged)
        .on("end", dragended);
    }

    // Cleanup
    return () => {
      simulation.stop();
    };
  }, [nodes, links, width, height]);

  return (
    <div className={`overflow-hidden ${className}`}>
      <svg 
        ref={svgRef} 
        viewBox={`0 0 ${width} ${height}`}
        className="w-full h-full border border-gray-200 dark:border-gray-700 rounded-lg"
        style={{ minHeight: '500px' }}
      />
    </div>
  );
};

export default NetworkGraph;