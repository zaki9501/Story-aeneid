import React from 'react';
import Card from './Card';
import { motion } from 'framer-motion';

interface StatsCardProps {
  title: string;
  value: string | number;
  icon?: React.ReactNode;
  change?: {
    value: number;
    isPositive: boolean;
  };
  footer?: React.ReactNode;
  className?: string;
}

const StatsCard: React.FC<StatsCardProps> = ({
  title,
  value,
  icon,
  change,
  footer,
  className = '',
}) => {
  return (
    <Card className={`${className}`}>
      <div className="p-2">
        <div className="flex justify-between items-start">
          <div>
            <p className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">{title}</p>
            <motion.h3 
              className="text-2xl font-bold text-gray-900 dark:text-white"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5 }}
            >
              {value}
            </motion.h3>
            
            {change && (
              <div className="flex items-center mt-1">
                <div
                  className={`flex items-center ${
                    change.isPositive ? 'text-green-600' : 'text-red-600'
                  }`}
                >
                  {change.isPositive ? (
                    <svg className="w-3 h-3 mr-1\" fill="currentColor\" viewBox="0 0 20 20\" xmlns="http://www.w3.org/2000/svg">
                      <path fillRule="evenodd\" d="M5.293 7.707a1 1 0 010-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 01-1.414 1.414L11 5.414V17a1 1 0 11-2 0V5.414L6.707 7.707a1 1 0 01-1.414 0z\" clipRule="evenodd"></path>
                    </svg>
                  ) : (
                    <svg className="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                      <path fillRule="evenodd" d="M14.707 12.293a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 111.414-1.414L9 14.586V3a1 1 0 012 0v11.586l2.293-2.293a1 1 0 011.414 0z" clipRule="evenodd"></path>
                    </svg>
                  )}
                  <span className="text-xs font-medium">
                    {change.value}%
                  </span>
                </div>
                <span className="text-xs text-gray-500 dark:text-gray-400 ml-1.5">from previous epoch</span>
              </div>
            )}
          </div>
          
          {icon && (
            <div className="p-2 bg-primary-50 dark:bg-primary-900/20 rounded-lg">
              {icon}
            </div>
          )}
        </div>
        
        {footer && (
          <div className="mt-4 pt-3 border-t border-gray-200 dark:border-gray-700">
            {footer}
          </div>
        )}
      </div>
    </Card>
  );
};

export default StatsCard;