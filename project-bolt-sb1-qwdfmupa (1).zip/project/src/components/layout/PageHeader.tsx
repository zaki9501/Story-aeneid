import React from 'react';
import { motion } from 'framer-motion';

interface PageHeaderProps {
  title: string;
  description?: string;
  actions?: React.ReactNode;
}

const PageHeader: React.FC<PageHeaderProps> = ({ title, description, actions }) => {
  return (
    <div className="mb-8">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between">
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <h1 className="text-2xl md:text-3xl font-bold text-gray-900 dark:text-white">{title}</h1>
          {description && (
            <p className="mt-1 text-gray-500 dark:text-gray-400">{description}</p>
          )}
        </motion.div>
        
        {actions && (
          <motion.div 
            className="mt-4 md:mt-0 space-x-3"
            initial={{ opacity: 0, x: 10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3, delay: 0.1 }}
          >
            {actions}
          </motion.div>
        )}
      </div>
      <div className="mt-6 h-1 w-full bg-gradient-to-r from-primary-500 via-secondary-500 to-accent-500 rounded-full"></div>
    </div>
  );
};

export default PageHeader;